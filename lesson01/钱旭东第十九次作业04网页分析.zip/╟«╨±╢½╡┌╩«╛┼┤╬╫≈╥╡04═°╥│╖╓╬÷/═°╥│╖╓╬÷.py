#-------第一部分--把很大一部分 不需要的信息去除掉 剩下的输出到一个新的文本里

fi=open("date.txt","r",encoding="utf-8")
f=open("univ.txt","w")
for line in fi:
    if "alt" in line:
        mk=line.split("alt=")[-1].split('"')#如果alt=在这一行里边 就把这一行以alt为分隔符分成两部分
                                            #并且取倒数第一个元素把这个元素再以双引号为界
                                            #分成几个部分
        print(mk)
        f.write("{}\n".format(mk[1]))
f.close()
fi.close()

#------第二部分----再次精简 把大学和学院放到了univ1文本里

n=0
m=0
p=0
f=open("univ.txt","r")
fo=open("univ1.txt","w")
lines = f.readlines()
f.close()
for line in lines:
    line = line.replace("\n","")
    if '大学生' in line:
        continue   #相当于把这一行给过滤掉
    elif '学院' in line and '大学' in line:
        if line[-2:] == '学院':
            m += 1
        elif line[-2:] == '大学':
            n += 1
        elif line[-2:] == '企业':
            p += 1
    elif '学院' in line:
        print('{}'.format(line))
        m += 1
        mk1=line
        fo.write("{}\n".format(mk1))
    elif '大学' in line:
        print('{}'.format(line))
        n += 1
        mk2=line
        fo.write("{}\n".format(mk2))
    else:
        p += 1
        mk3=line
        fo.write("{}\n".format(mk3))
print("包含大学的名称数量是{}".format(n))#输出大学计数
print("包含学院的名称数量是{}".format(m))#输出学院计数
print("包含企业的名称数量是{}".format(p))#输出企业计数
fo.close()


#-----第三部分----- 画图
#载入库
from pyecharts import options as opts
from pyecharts.charts import Bar
from pyecharts.faker import Faker
ls1 = ["大学","学院","企业"]
ls2 = [n,m,p]
c = (
    Bar()
    .add_xaxis(ls1)
    .add_yaxis("数量",ls2)
    .set_global_opts(
        title_opts=opts.TitleOpts(title="MOOC分布图"),
        datazoom_opts=opts.DataZoomOpts(),
    )
    .render("MOOC分析图.html")
)



























