import re
with open("诸葛亮3.txt","r",encoding="utf-8") as f:
    s=f.readlines()
f1=open("诸葛亮4.txt","w",encoding="utf-8")
f2=open("无用2.txt","w",encoding="utf-8")
for s1 in s:
    ret=re.match("[\u4e00-\u9fa5\W]{,100}诸葛亮[\u4e00-\u9fa5\W]{,100}：“",s1,re.X)
    if ret:
        f1.write(s1)
    else :
        f2.write(s1)
f1.close()
f2.close()
