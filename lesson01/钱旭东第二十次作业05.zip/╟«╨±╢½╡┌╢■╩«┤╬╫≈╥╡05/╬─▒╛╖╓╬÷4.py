with open("诸葛亮4.txt","r",encoding="utf-8") as f:
    s=f.readlines()
list1=[]    
for s1 in s:
    a=0
    b=""
    for i in s1:
        if a==1:
            b+=i
        if i=="：":
            a=1
    c=b.replace("\n","")    
    list1.append(c)
f1=open("诸葛亮5.txt","w",encoding="utf-8")
for i in list1:
    f1.write(i)
f1.close()

with open("诸葛亮5.txt","r",encoding="utf-8") as f2:
    s2=f2.read()

d=""
e=1
for i in s2:
    if i=="(":
        e=0
    if e==1:
        d+=i
    if i==")":
        e=1
f1=open("诸葛亮5.txt","w",encoding="utf-8")

f1.write(d)
f1.close()        
