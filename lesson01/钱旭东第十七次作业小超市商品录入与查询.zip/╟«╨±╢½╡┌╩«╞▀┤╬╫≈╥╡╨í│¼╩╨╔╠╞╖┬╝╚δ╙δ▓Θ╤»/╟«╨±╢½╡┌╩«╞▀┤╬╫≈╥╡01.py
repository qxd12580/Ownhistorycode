#商品信息管理系统
#实现功能：录入，查询，退出系统

#--------------------------第一 载入库------------------------------
#--------------------------第二 数据索引----------------------------
#--------------------------第三 子函数-------------------------------
def judge():#定义判断函数
    global a
    global b
    global x
    f1=open("code.txt",'r')
    s=f1.read()
    list=s.split(',')
    for i in range(len(list)):
        if list[i]==bn:
            a=1
            b=i
            x=i
            break
        else:
            continue
#-------------商品码库---
def file1():
    filename1=input('请输入文件名(装商品码)：')
    f1=open(filename1,'a')    #追加打开文件，直接在文件后边写
    cd=code+','
    f1.write(cd)
    f1.close()
#-------------商品名称库
def file2():
    filename2=input('请输入文件名(装商品名)：')
    f2=open(filename2,'a')    
    nm=name+','
    f2.write(nm)
    f2.close()
#-------------价格库-----
def file3():
    filename3=input('请输入文件名(装价格)：')
    f3=open(filename3,'a')    
    pi=price+','
    f3.write(pi)
    f3.close()
#--------------------主程序----------------------------
print("欢迎使用商品管理系统")
k=''
while(k==''):
    print("*************")
    print("1、录入商品信息")
    print("2、查询商品信息")
    print("3、退出管理系统")
    print("*************")
    num = int(input("请选择功能："))

    #录入功能
    if num == 1:
        filename=input("请输入总库文件名：")
        code=input("请扫描条码：")
        name=input("请输入商品名：")
        price=input("请输入单价：")
        f=open(filename,'a')
        fn=code+'\n'+name+'\n'+price
        fn=fn+'\n'
        f.write(fn)
        print("商品录入成功！\n")
        f.close()
        file1()
        file2()
        file3()
        k=input("要再来一次吗?(回车继续)")
    #查找功能
    elif num == 2:
        f1=open("code.txt",'r',)
        bn=input("请输入商品的码号：")
        f2=open("name.txt",'r') #装有名称的列表
        t=f2.read()             
        list1=t.split(',')
        f3=open("price.txt",'r')
        c=f3.read()
        list2=c.split(',')
        judge()  #判断一下
        v=list1[b]#此时的商品名称
        q=list2[x]#此时的价格
        if a==1:
            print("商品名称为{}".format(v))
            print("商品单价为{}".format(q))
        else:
            print("此商品不存在！")
        k=input("要再来一次吗?(回车继续)")
    elif num == 3:
        print("成功退出系统！")
        break
















