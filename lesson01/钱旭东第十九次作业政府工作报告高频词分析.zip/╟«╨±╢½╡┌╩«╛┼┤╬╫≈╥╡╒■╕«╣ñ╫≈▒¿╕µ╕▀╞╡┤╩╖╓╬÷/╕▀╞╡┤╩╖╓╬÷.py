#--------第一 载入库------
import jieba
from pyecharts import options as opts
from pyecharts.charts import Pie
from pyecharts.faker import Faker
#--------第二 数据---------
#-----2021
mk={}#创建一个字典
with open('政府工作报告2021.txt','r',encoding='utf-8') as f:#打开文件把内容给到f然后关闭
    zf1 = f.readlines()    #得到文件内容列表
m=[]  #存2021
ls1={}#存相同键
ls2={}#存相同值
ls3={}#存相同的
ls4=[]#存键
ls5=[]#存值
ls9=[]#存键
ls10=[]#存值
sm={}
df1={}
df2={}
#-----2022
mk1={}#创建一个字典
with open('政府工作报告2022.txt','r',encoding='utf-8') as f:#打开文件把内容给到f然后关闭
    zf2 = f.readlines()    #得到文件内容列表
k=[]  #存2022
#------- 第四 主程序---------
#-------------2021--------------
for z1 in zf1:
    k1=jieba.lcut(z1, cut_all = True)   #全模式切分，
    for c1 in k1:
        if len(c1)==2:
            mk[c1] = mk.get(c1,0) + 1   #获取键值对,有这项加一 没这项给值填0                               

mp = list(mk.items())#item函数 以列表形式返回可遍历的（键,值）元组 数组

mp.sort(key= lambda x:x[1], reverse = True)  #降序
for i in range(len(mp)):#获取前二十高频词
    m.append(mp[i])

#----------2022------------------------
for z2 in zf2:
    k2=jieba.lcut(z2, cut_all = True)   #全模式切分，
    for c2 in k2:
        if len(c2)==2:
            mk1[c2] = mk1.get(c2,0) + 1   #获取键值对,有这项加一 没这项给值填0                               
qp = list(mk1.items())#item函数 以列表形式返回可遍历的（键,值）元组 数组

qp.sort(key= lambda x:x[1], reverse = True)  #降序
for i in range(len(qp)):#获取前二十高频词
    k.append(qp[i])

#---相同的---
for j in range(len(k)):#找相同的
    for i in range(len(m)):
        if k[j][0] in m[i][0]:
            ls3[m[i][0]]=m[i][1]+k[j][1]#存2021相同
ls1=list(ls3.items())
ls1.sort(key=lambda x:x[1],reverse=True)
for i in range(10):
    sm[ls1[i][0]]=ls1[i][1]
print(ls1[:10])
ls1=list(sm.keys())
ls2=list(sm.values())
'''
#-------画相同的-----------
c = (
    Pie()
    .add("", [list(z) for z in zip(ls1,ls2)])
    .set_colors(["blue", "green", "yellow", "red", "pink", "orange", "purple","lime","black","plum"])
    .set_global_opts(title_opts=opts.TitleOpts(title="共同高频词"))
    .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}: {c}"))
    .render("相同.html")
)
'''
#----找不同的------------
df1={}
ls5 = []#存2021词语
ls7 = []#存2022词语
ls6 = []#存2022不同的词语
ls8 = []#存2021不同的词语
for i in range(len(m)):#显示ls3所有词语
    ls5.append(m[i][0])
for i in range(len(k)):#遍历找出不同
    if k[i][0] not in ls5:
        ls6.append(k[i])
for i in range(len(k)):#显示ls6所有词语
    ls7.append(k[i][0])
for i in range(len(m)):#遍历找出不同
    if m[i][0] not in ls7:
        ls8.append(m[i])
ls6.sort(key=lambda e:e[1],reverse=True)
ls8.sort(key=lambda e:e[1],reverse=True)
for i in range(5):
    df1[ls6[i][0]] = ls6[i][1]
for i in range(5):
    df2[ls8[i][0]] = ls8[i][1]    
print(ls6[:5])
print(ls8[:5])
ls4=list(df1.keys())
ls5=list(df1.values())
ls9=list(df2.keys())
ls10=list(df2.values())
#----画不同
'''
#--2022
c = (
    Pie()
    .add("", [list(z) for z in zip(ls4,ls5)])
    .set_colors(["blue", "green", "yellow", "red", "pink", "orange", "purple","lime","black","plum"])
    .set_global_opts(title_opts=opts.TitleOpts(title="不共频词"))
    .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}: {c}"))
    .render("2022特有的高频词.html")
)
'''
c = (
    Pie()
    .add("", [list(z) for z in zip(ls9,ls10)])
    .set_colors(["blue", "green", "yellow", "red", "pink", "orange", "purple","lime","black","plum"])
    .set_global_opts(title_opts=opts.TitleOpts(title="不共频词"))
    .set_series_opts(label_opts=opts.LabelOpts(formatter="{b}: {c}"))
    .render("2021特有的高频词.html")
)
#一次画一个

















