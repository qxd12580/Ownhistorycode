#--------------------------第一  载入库-------------------------
import turtle
#--------------------------第二 数据驱动------------------------
A = [["人", 0], ["羊", 0], ["狼", 0], ["草", 0]]
# -------------------------第三 子函数定义----------------------
#--------------------------第四    主程序 --------------------------
t = [turtle.Turtle() for i in range(5)]
turtle.register_shape("羊.gif")
turtle.register_shape("狼.gif")
turtle.register_shape("草.gif")
turtle.register_shape("农民.gif")
t[0].shape("农民.gif")
t[1].shape("羊.gif")         # 只能是gif文件
t[2].shape("狼.gif")
t[3].shape("草.gif")
t[4].speed(10)
t[0].pensize(5)
for i in range(4):
    t[i].penup()
    t[i].speed(100)
t[4].penup()
t[4].goto(-250, -1200)
t[4].pendown()
t[4].color("sky blue")
t[4].begin_fill()
t[4].goto(250, -1200)
t[4].goto(250, 1200)
t[4].goto(-250, 1200)
t[4].end_fill()
t[1].goto(-700, -350)
t[2].goto(-700, 0)
t[3].goto(-700, 350)
t[0].goto(-700, 0)
a = 0
b = 0
for i in range(1, len(A)):
    if A[i][1] == 0:  # 在河左边的执行  羊先走
        A[i][1] = 1
        A[0][1] = 1  # 先走一步
        if A[0][1] != A[1][1] == A[2][1] or A[0][1] != A[1][1] == A[3][1]:
            A[i][1] = 0  # 不满足条件就返回到之前情况                           #下同
            A[0][1] = 0

        else:
            a = A[i][0]
            t[0].speed(5)  # 让待会的船不载这个东西
            t[0].goto(-700, -700 + 350 * i)
            t[0].speed(100)  # 满足
            for m in range(-25, 26):
                t[0].goto(28 * m, -700 + 350 * i)
                t[i].goto(28 * m, -700 + 350 * i)
            break
while b == 0:  # 进入循环
    for i in range(1, len(A)):
        if A[i][1] == 1 and A[i][0] != a:
            A[i][1] = 0
            A[0][1] = 0
            if A[0][1] != A[1][1] == A[2][1] or A[0][1] != A[1][1] == A[3][1]:  # 回去
                A[i][1] = 1
                A[0][1] = 1
            else:
                a = A[i][0]
                t[0].speed(5)
                t[0].goto(700, -700 + 350 * i)  # 满足
                t[0].speed(100)
                for m in range(-25, 26):
                    t[0].goto(-28 * m, -700 + 350 * i)
                    t[i].goto(-28 * m, -700 + 350 * i)
                break
    for i in range(1, len(A)):
        if A[i][1] == 0 and A[i][0] != a:
            A[i][1] = 1
            A[0][1] = 1
            if A[0][1] != A[1][1] == A[2][1] or A[0][1] != A[1][1] == A[3][1]:  # 再过河
                A[i][1] = 0
                A[0][1] = 0
            else:
                a = A[i][0]
                t[0].speed(5)
                t[0].goto(-700, -700 + 350 * i)  # 满足
                t[0].speed(100)
                for m in range(-25, 26):
                    t[0].goto(28 * m, -700 + 350 * i)
                    t[i].goto(28 * m, -700 + 350 * i)

                break
    if A[2][1] + A[3][1] == 2:         #此时所有人都过河了
        A[1][1] = 1
        A[0][1] = 1
        t[0].speed(5)
        t[0].goto(-700, -350)  # 满足
        t[0].speed(100)
        for m in range(-25, 26):
            t[0].goto(28 * m, -350)
            t[1].goto(28 * m, -350)
        break














































    
