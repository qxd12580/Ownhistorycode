#诸葛亮的别名 亮  孔明  诸葛孔明   卧龙先生  卧龙  

f=open("诸葛亮.txt","r",encoding="utf-8")
fo=open("诸葛亮2.txt","w")
n=0

for line in f:
    line=line.replace("孔明","诸葛亮")
    line=line.replace("诸葛孔明","诸葛亮")
    line=line.replace("卧龙先生","诸葛亮")
    line=line.replace("卧龙","诸葛亮")
    fo.write("{}\n".format(line))
f.close()        
fo.close()
    
